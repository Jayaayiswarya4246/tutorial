# Data Analysis: Investigating Netflix Movies

This project is part of [DataCamp's Data Scientist with Python Track](https://app.datacamp.com/learn/career-tracks/data-scientist-with-python).  
The goal is to apply the skills learned in the basic and intermediate Python courses to solve a real-world data science project.  
The full description can be viewed [in the project page](https://www.datacamp.com/projects/1237).  

